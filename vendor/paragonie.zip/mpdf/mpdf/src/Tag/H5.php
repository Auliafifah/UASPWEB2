<?php

namespace Mpdf\Tag;

class H5 extends BlockTag
{


}
